#include<iostream>
#include<string>
#include<conio.h>
#include<fstream>

using namespace std;

char choice;

void showMenu()
{
	system("cls");
	cout << "1.Exercise Plan"<<endl;
	cout << "2.Trainer Schedule" << endl;
	cout << "3.Hall Schedule" << endl;
	cout << "4.Customers Subscription" << endl;
	cout << "Enter your choice" << endl;
	cin >> choice;

}                                                                                     

class gym_hall
{	
public:
	
	void hall()
	{
		string avablility = "Hall one : 5am - 11am";
		fstream halltime;
		

		halltime.open("avablility.txt",ios::app);
		
			getline(halltime, avablility);

			cout << avablility << endl;
		
			halltime.close();
	}
	
	void hall2()
	{

		fstream halltime2;
		string avablility2 = "Hall Two : 5pm - 11pm";

		halltime2.open("avablility.txt", ios::app);

		getline(halltime2, avablility2);

		cout << avablility2 << endl;

		halltime2.close();
	}
	
};

class trainer {
public:
	
	void trainers()
	{
		fstream ex_plan;
		string trainers = "Shehriyar Sultan avability time is 5am-12pm";

		ex_plan.open("exerciseplan.txt", ios::app);
		
		ex_plan << trainers;
		cout << trainers;
		ex_plan.close();
	}
};

class exerciseplan
{
	string plann= "Arms and legs";
	
	void input()
	{
		fstream in_plan;

		in_plan.open("exerciseplan.txt", ios::in);
		in_plan << plann;

	}
public:
	void exx_plan()
	{
		fstream ex_plan;

		ex_plan.open("exerciseplan.txt", ios::app);
		ex_plan.close();
		ex_plan >> plann;
		cout << plann;
	}

};

class Customers_Subscription
{
public:
	void planForSubs()
	{
		fstream Subsplan;
		string plan_price = "For Six months subscription = 30000";

		Subsplan.open("plans_Subs.txt", ios::app);

		Subsplan << plan_price;
		cout << plan_price;
		Subsplan.close();

	}
};

//Driver Tool
int main()
{
	showMenu();

	exerciseplan obj1;
	trainer obj2;
	gym_hall obj3;
	Customers_Subscription obj4;
	switch (choice)
	{
	case'1':
		cout << "Plan for today is : ";
		obj1.exx_plan();
		break;

	case'2':
		cout << "Scheduled trainer for today is : ";
		break;

	case'3':
		cout << "Choice your hall schedule : ";
		obj3.hall();
		obj3.hall2();
		break;

	case'4':
		cout << "Choice your subscription plan : ";
		obj4.planForSubs();
		break;

	default:
		cout << "Chutii kr";
		break;
	}

	system("pause");
}